import './App.css';

import AgoraVideoMedia from './AgoraVideoMedia'

function App() {
  return (
    <div className="App">
      <AgoraVideoMedia />
    </div>
  )
}

export default App;
