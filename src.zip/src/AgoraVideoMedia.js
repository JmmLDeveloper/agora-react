import React, { useCallback, useEffect, useState } from 'react'
import AgoraRTC from 'agora-rtc-sdk'

const angoraConfig = {
  mode: 'rtc',
  appId: '3115e1973648472fb304395111f753da',
  token: '0063115e1973648472fb304395111f753daIAC6c3YL0eX4+15U85PcM/kAxNDigmSj7ui5n5SA/nouEQx+f9gAAAAAEAAPIFh7SjbRXwEAAQBKNtFf',
  room: 'test'
}

AgoraRTC.Logger.setLogLevel( AgoraRTC.Logger.NONE )


const client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });
const screenClient = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });

const localStream = AgoraRTC.createStream({
  audio: true,
  video: true,
  screen: false
});

const localScreenStream = AgoraRTC.createStream({
  audio: false,
  video: false,
  screen: true,
  screenAudio: true,
  mediaSource: 'screen',
});

function StreamVideo({ stream }) {
  
  const id = stream.getId()
  console.log('reeeeeeeeeeeeemaaaaaaaaaaaaaaalditoooooooooo')

  console.log(id)
  useEffect(()=>{
  },[])


  return (
    <div id={id} className="video-box">
    </div>
  )
}

function initNormalClient() {
  return new Promise((resolve,reject)=>{
    client.init(angoraConfig.appId);

    client.join(angoraConfig.token, angoraConfig.room, null, (uid) => {
      localStream.init(() => {
        client.publish(localStream, function (err) {
          console.log("[ERROR] : publish local stream error: " + err);
          reject()
        })
        resolve(localStream);
      },()=>{
        console.log('failure at init normal local stream')
        reject()
      });
    },()=>{
      console.log('there seems to be and error with localStream')
      reject()
    })
  })
}


export default function AgoraVideoMedia() {
  const [audioFlag, setAudioFlag] = useState(true)
  const [videoFlag, setVideoFlag] = useState(false)
  const [screenFlag, setScreenFlag] = useState(false)
  const [isMediaInit,setIsMediaInit] = useState(false)

  useEffect(()=>{
    (async ()=>{

      if(!isMediaInit) {
        let aws = await initNormalClient()
        setIsMediaInit(true)
      }
    })()
  },[isMediaInit])


  const toggleAudio = () => {
    if (audioFlag) {
      setAudioFlag(false)
    }
    else {
      setAudioFlag(true)
    }
  }
  const toggleVideo = () => {
    if (videoFlag) {
      setVideoFlag(false)
    }
    else {
      setVideoFlag(true)
    }
  }
  const toggleScreen = () => {
    if (screenFlag) {
      setScreenFlag(false)
    }
    else {
      setScreenFlag(true)
    }
  }
  const endCall = () => {
  }

  console.log( isMediaInit )

  return (

    <div id="agora-main-container" >
      <div id="streams">
        {
          isMediaInit && <StreamVideo stream={localStream}/>
        }
      </div>
      <div id="agora-controls">
        <button onClick={toggleAudio}>
          {
            audioFlag ?
              <span className="material-icons">
                mic
            </span> :
              <span className="material-icons">
                mic_off
            </span>
          }
        </button>
        <button onClick={toggleVideo}>
          {
            videoFlag ?
              <span className="material-icons">
                videocam
            </span> :
              <span className="material-icons">
                videocam_off
            </span>
          }
        </button>
        <button onClick={toggleScreen}>
          {
            screenFlag ?
              <span className="material-icons">
                screen_share
            </span> :
              <span className="material-icons">
                stop_screen_share
            </span>
          }
        </button>
        <button>
          <span className="material-icons">
            call_end
        </span>
        </button>
      </div>
    </div>
  )
}

